#!/usr/bin/python
# -*-coding: UTF-8 -*-
# from yumi import YuMiSubscriber
# from yumi import YuMiRobot
# #from yumi.one_arm_d import ArmD
# from yumi import YuMiState
# from yumi import YuMiSubscriber
from copy import deepcopy
from numpy import *
import threading
#import pythoncom
#import pyHook
import time
import numpy as np
import sys
import os
import re
import test_main


# only one axis,in realrobot is y axis,in code I use in my_X_DDPG,but you should
# use it in second params,eg.(mov_to_tcp([*,params,*,*,*,*]))

teach_done = -1
teach_start = 0
playback_start = 0
playback_done = -1
speed_down = 0
myo_done = -1
myo_start = 1

error_times = 0

default_sleep_time = 10

initial_theta = [3.11995868 - 0.05851983 - 0.0294507]
initial_pose = [0.32596256, 0.0744743656, 0.298545745, 3.11995868, -0.05851983, -0.0294507]


class TPM(object):

	def __init__(self, ):
		self.pre_right_state = [0.0,0.0,0.0,0.0,0.0,0.0,0.0]
		self.pre_point_R = [0.0,0.0,0.0,0.0,0.0,0.0,0.0]
		self.accuracy = 2.0#0.01
		self.Sampling_rate = 0.1
		self.n_restore=1

# 这个应该是用手or手环控制Yumi运动，然后不断记录Yumi信息到Right_statenew.txt中。teach_done由按键关闭  只有右臂？
# 	def Teaching(self, teach_file_name='Right_statenew.txt'):
# 		#global accuracy
# 		#global teach_done
# 		sub = YuMiSubscriber()
# 		sub.start()
# 		if os.path.exists(teach_file_name):
# 			os.remove(teach_file_name)
# 		while True:
# 			'''
# 			right_pose = sub.left.get_pose()
# 			right_pose = sub.right.get_pose()
# 			left_state = sub.left.get_state()
# 			right_state = sub.right.get_state()
# 			left_torque = sub.left.get_torque()
# 			right_torque = sub.right.get_torque()
#
# 			print 'L:',left_torque
# 			time.sleep(1)
# 			print 'R:',right_torque
# 			'''
# 			#set_speed(speed_data, wait_for_res=True)
# 			# 获得的是力矩么   是什么形式
# 			right_state = sub.right.get_state()
# 			#right_state = [1.0,2.0,3.0,4.0,5.0,6.0,7.0]
# 			time.sleep(self.Sampling_rate)
# 			#print right_state[1].vals
# 			#pre_right_state=YuMiState(vals=pre_right_state)
# 			#if right_state[1] != pre_right_state:
# 			if max(abs(array(right_state[1].vals) - array(self.pre_right_state)))>=self.accuracy:
# 				right_data = deepcopy(right_state[1].vals)
# 				right_data.append(speed_down)
# 				with open(teach_file_name,"a") as text_file:
# 						text_file.write("{0}\n".format(right_data))
# 				print (right_data)
# 				self.pre_right_state = right_state[1].vals
# 			if teach_done ==1:
# 				break

# 动作回放   数据维度为8，7个状态加1个速度
# 	def Playback(self, restore_file_name='Right_statenew.txt', column_data=8):
# 		global teach_start
# 		global playback_start
# 		#global pre_point_R
# 		#global accuracy
# 		#global playback_done
# 		y = YuMiRobot()
# 		y.calibrate_grippers()
# 		#y.get_v()
# 		y.set_v(7000)
# 		#state=self.y.left.get_state()
# 		#'''restore
# 		for num in range(self.n_restore):
# 			with open(restore_file_name,'r') as f:
# 				msg = f.readlines()
# 				row_data = len(msg)
# 				test_data=zeros((row_data,column_data))
# 				for i,strings in enumerate(msg):
# 					#print type(strings)
# 					strings=strings.strip()
# 					strings=strings.strip('[]')
# 					strings=strings.split(', ')
# 					#print strings
# 					test_data[i,:] = strings
# 			#print test_data
# 			# test_data已经把要回放地数据读出来了
# 			for n_data in range(row_data):
# 				point_R = test_data[n_data,:-1]
# 				speed_level = test_data[n_data,-1]
# 				#print speed_level
# 				# 什么意思
# 				if speed_level or speed_down == 1:
# 					self.accuracy = 2.0
# 					y.set_v(50)
# 				else:
# 					self.accuracy = 20.0
# 					y.set_v(7000)
# 				#pre_point_R记录的是上次要到达（现在可能已经到达）的位置
# 				if max(abs(array(point_R) - array(self.pre_point_R)))>=self.accuracy:
# 					#print point_R
# 					# 这个语句什么意思？
# 					point_R_=YuMiState(vals=point_R)
# 					y.right.goto_state(point_R_)
# 					self.pre_point_R = point_R
# 				if playback_done == 1:
# 					break
# 			if playback_done == 1:
# 				break
# 		teach_start = 0
# 		playback_start = 0
# 		#'''
# 		'''GMM-GMR
# 		for num in range(n_restore):
# 			with open('demon_file1.txt','r') as f:
# 				msg = f.readlines()
# 				row_data = len(msg)
# 				test_data=zeros((row_data,column_data))
# 				for i,strings in enumerate(msg):
# 					#print type(strings)
# 					strings=strings.strip()
# 					strings=strings.split(' ')
# 					#print strings
# 					test_data[i,:] = strings
# 			#print test_data
#
# 			for n_data in range(row_data):
# 				point_R = test_data[n_data,:-1]
# 				speed_level = test_data[n_data,-1]
# 				if speed_level or speed_down == 1:
# 					y.set_v(100)
# 				else:
# 					y.set_v(7000)
# 				if max(abs(array(point_R) - array(pre_point_R)))>=accuracy:
# 					print point_R
# 					point_R_=YuMiState(vals=point_R)
# 					y.right.goto_state(point_R_)
# 					pre_point_R = point_R
# 				if playback_done == 1:
# 					break
# 			if playback_done == 1:
# 				break
# 		teach_start = 0
# 		playback_start = 0
# 		'''

	# def reset_initial(self):
	# 	# 第一个点
	# 	right_pose.translation[0] = point_1[0]
	# 	# right_pose.translation[1] = point_1[1]#gap position 1
	# 	right_pose.translation[1] = point_1[1] + 0.05  # gap position 2
	#
	# 	Yumi.right.goto_pose(right_pose, linear=True, relative=True, wait_for_res=True)
	# 	time.sleep(1)
	# 	Yumi.right.close_gripper()
	# 	time.sleep(1)
	# 	print("cap point")
	# 	####Test###
	# 	Yumi.right.goto_pose_delta((0.0, 0.0, -(0.105)))  # 向下10.5cm
	# 	time.sleep(1)
	# 	###########
	# 	print('向下10.5cm')
	# 	Yumi.right.open_gripper()
	# 	Yumi.right.set_gripper_force(25, wait_for_res=True)
	# 	time.sleep(1)
	# 	###########
	# 	Yumi.right.goto_pose_delta((0.0, 0.0, 0.01))
	# 	Yumi.right.goto_pose_delta((0.05, 0.0, 0.155))  # (x,self.y,z)#向cm
	# 	time.sleep(20)
	# 	print('向前5cm, 向上15.5cm')
	# 	####Test###
	# 	# Yumi.right.goto_pose_delta((0.0, 0.0, 0.215))#(x,self.y,z)#向上20.5cm
	# 	# print('向上10.5cm')
	# 	# 第二个点
	# 	high_pose = Yumi.right.get_pose()
	# 	right_pose.translation[2] = high_pose.translation[2]
	# 	'''
	# 	right_pose.translation[0] = point_2[0]
	# 	right_pose.translation[1] = point_2[1]
	# 	Yumi.right.goto_pose(right_pose, linear=True, relative=True, wait_for_res=True)
	# 	'''
	# 	final_pose = right_pose
	# 	print('rl start point')
	# 	print(final_pose)
	# 	# 把当前点作为初始点写入Yumi_point.txt
	# 	with open("Yumi_point.txt", "w") as text_file:
	# 		text_file.write("{:.3f}\n{:.3f}\n{:.3f}\n".format(point_2[0], point_2[1], point_2[2]))

		# Yumi首先运动到某一位置，然后不断根据强化学习文件指明的位置去运动，如果ESC，Yumi回到point_R点
	def Myo_controll(self, point_R, x_delta, myoX_file_name='YumiX_point.txt', myoD_file_name='YumiD_point.txt'):
		#Yumi.set_v(7000)
		#Yumi.right.calibrate_gripper()
		# X和D分别代表什么，这个值是什么意思
		reach_pose = initial_pose
		self.transX = [0, 0, 0]#改为初始值
		self.transD = [0, 0, 0]#改为初始值
		assert len(point_R) == 3, "must be 3 item!"
		#os.system("get_1myo.py")
		#right_pose = Yumi.right.get_pose()
		while True:
			#是要读出目标位置信息么
			#print('will read oytd.txt')
			with open(r'/home/cuiben/study_code/UR5_RL/outd.txt', 'r') as f:
				t_picture = f.read()
			t_picture = t_picture.strip('\n').split(' ')
			#print (t_picture)
			# 这句不知道具体是什么流程
			# clear_data = re.match(r'dx:([0-9\.\-]*)[\s]*dy:([0-9\.\-]*)[\s]*ddepth:([0-9\.\-]*)[\s]*', t_picture)
			# #这部分是要要做什么？  此前已经到了point_2点了   一个固定化地抓取？
			# #print('will check correct')
			# print(clear_data)
			# if clear_data !=None:
			# 	if float(clear_data.group(1)) == 0.0:#dx
			if t_picture !=None:
				# print(t_picture)
				# print(t_picture[0])
				if t_picture[0] != '':
					if np.abs(float(t_picture[0])) <= 2 :#dx
						print('已对准')
						test_main.move_to_tcp(initial_pose)
						time.sleep(10)
						# #确定对准后，一点一点下降，但是怎么确定下降这么多就正好了呢，不会发生机械碰撞或者高度不够
						# right_pose.translation[2] -= 0.002
						# Yumi.right.goto_pose(right_pose, linear=False, relative=True, wait_for_res=True)
						# print('下降2mm')
						# right_pose.translation[2] -= 0.002
						# Yumi.right.goto_pose(right_pose, linear=False, relative=True, wait_for_res=True)
						# print('下降2mm')
						# right_pose.translation[2] -= 0.002
						# Yumi.right.goto_pose(right_pose, linear=False, relative=True, wait_for_res=True)
						# print('下降2mm')
						# right_pose.translation[2] -= 0.002
						# Yumi.right.goto_pose(right_pose, linear=False, relative=True, wait_for_res=True)
						# print('下降2mm')
						# right_pose.translation[2] -= 0.002
						# Yumi.right.goto_pose(right_pose, linear=False, relative=True, wait_for_res=True)
						# print('下降2mm')
						# right_pose.translation[2] -= 0.002
						# Yumi.right.goto_pose(right_pose, linear=False, relative=True, wait_for_res=True)
						# print('下降2mm')
						#
						# # you yi C
						# right_pose.translation[2] -= 0.004
						# Yumi.right.goto_pose(right_pose, linear=False, relative=True, wait_for_res=True)
						# print('下降3mm')
						#
						# right_pose.translation[2] -= 0.001#白瓶0.004
						# Yumi.right.goto_pose(right_pose, linear=False, relative=True, wait_for_res=True)
						# print('下降4mm')
						# Yumi.right.goto_pose_delta((0.0, 0.0, 0.0), rotation=(0, 0, 90))
						# #Yumi.right.goto_pose_delta((0.0, 0.0, -0.002))
						# print('下降2mm')
						# print('wring over')
						'''
						time.sleep(10)
						state = Yumi.right.get_state()
						print(str(state))
						clear_data = re.match(r'\[([0-9\.\-]*),[\s]*([0-9\.\-]*),[\s]*([0-9\.\-]*),[\s]*([0-9\.\-]*),[\s]*([0-9\.\-]*),[\s]*([0-9\.\-]*),[\s]*([0-9\.\-]*)[\s]*\]', str(state))	
						state_R_ = []
						for i in range(7):
							if i == 6:
								joint = float(clear_data.group(i+1)) + 15.78
							elif i == 5:
								joint = float(clear_data.group(i + 1)) + 60
							else:
								joint = float(clear_data.group(i+1))
							state_R_.append(joint)
						print(state_R_)
						state_R=YuMiState(vals=state_R_)
						Yumi.right.goto_state(state_R)
						'''
						#Yumi.right.close_gripper()
						#这个点是？
						# try:
						# 	#Yumi.right.goto_pose_delta((-0.05, 0.0, 0.0))
						# except:
						# 	pass
						'''
						right_pose.translation[1] -= 0.05
						Yumi.right.goto_pose(right_pose, linear=False, relative=True, wait_for_res=True)
						'''
						#right_pose.translation = point_R
						#right_pose.translation[2] = 0.087
						# right_pose.translation[0] = point_R[0]
						# right_pose.translation[1] = point_R[1]
						# right_pose.translation[2] = point_R[2]
						# print(right_pose)
						# try:
						# 	Yumi.right.goto_pose(right_pose, linear=True, relative=True, wait_for_res=True)
						# 	self.reset_initial()
						# 	print("have done")
						# except:
						# 	try:
						# 		Yumi.right.goto_pose(init_pose, linear=True, relative=True, wait_for_res=True)
						# 		Yumi.right.goto_pose(right_pose, linear=True, relative=True, wait_for_res=True)
						# 		Yumi.right.goto_pose(final_pose, linear=True, relative=True, wait_for_res=True)
						# 		self.reset_initial()
						# 		print("have done wave")
						# 	except:
						# 		pass
						# 	pass

						break
					else:
						#强化学习文件中不断向下面这两个文件写入到达状态
						#print("not correct,will read reach_state")
						with open("pointX_reach.txt", 'r') as fX:
							pointX_reach = fX.read()
						with open("pointD_reach.txt", 'r') as fR:
							pointD_reach = fR.read()
						#print('pointX_reach:', pointX_reach, 'pointD_reach:', pointD_reach)
						#print('len:', len(pointX_reach))
						'''
						with open("pointX_reach.txt", "w") as text_file:
							text_file.write('0')
						with open("pointD_reach.txt", "w") as text_file:
							text_file.write('0')
						'''
						if (len(pointX_reach) == 1)and(len(pointD_reach) == 1):
							#if (int(pointX_reach[0]) == 0)and(int(pointD_reach[0]) == 0):
							if (int(pointX_reach[0]) == 0) or (int(pointD_reach[0]) == 0):
								# 读取要达到的点
								#print("will read reach point")
								with open(myoX_file_name, 'r') as fX:
									msgX = fX.readlines()
								for i, strings in enumerate(msgX):
									self.transX[i] = float(strings.strip())
								with open(myoD_file_name, 'r') as fD:
									msgD = fD.readlines()
								for i, strings in enumerate(msgD):
									self.transD[i] = float(strings.strip())

								'''
								if self.angle[3]==1:
									Yumi.right.close_gripper()
									Yumi.right.set_gripper_force(25, wait_for_res=True)
									self.angle[3] = 0
								elif self.angle[3]==-1:
									Yumi.right.open_gripper()
									self.angle[3] = 0
								if self.angle == [6,6,6,6]:
									Yumi.right.close_gripper()
									Yumi.right.reset_home()	
									sys.exit()	
					
								if self.trans[1] < 0.08:
									self.trans[1] = 0.08
								elif self.trans[1] > 0.29074:
									self.trans[1] = 0.29074	
					
								if self.angle[2]>0.7:#0.9左旋
									Yumi.right.goto_pose_delta((-(x_delta),0.0,0.0))#(x,self.y,z)#向后1cm
								if self.angle[2]<-0.8:#右旋
									Yumi.right.goto_pose_delta((x_delta,0.0,0.0))#(x,self.y,z)#向前1cm
								'''
								#if abs(self.trans[2] - right_pose.translation[2])>=0.005 or abs(self.trans[1] - right_pose.translation[1])>=0.005:
								# right_pose.translation[0] = self.transX[0]
								# right_pose.translation[1] = self.transD[1]

								reach_pose[1] = self.transX[0]
								print(reach_pose)
								test_main.move_to_tcp(reach_pose)
								#time.sleep(default_sleep_time-5)
								while True:

									current_pose = test_main.get_current_tcp()
									if abs(current_pose[1] - reach_pose[1])<0.01:
										break


								#try:
								#print (self.transX[0], self.transD[1])
								#运动过去并修改状态文件的值
								#没看到D方向的移动
								#print(right_pose.translation)

								# try:
								# 	Yumi.right.goto_pose(right_pose, linear=False, relative=True, wait_for_res=True)#绝对位置
								# except:
								# 	right_pose.translation[0] = right_pose.translation[0] - 0.0001
								# 	pass

								with open("pointX_reach.txt", "w") as text_file:
									text_file.write('1')
								with open("pointD_reach.txt", "w") as text_file:
									text_file.write('1')
									#print "arm {0}".format(self.isleft)
									#time.sleep(0.1)
								#except:
								#	print ("position is unreached!")
							else:
									#print int(point_reach[0])
									pass
							# myo control?
							if myo_done ==1:
								print("have no function now")
								#Yumi.right.reset_home()
								# right_pose.translation = point_R
								# #right_pose.translation[2] = 0.087
								# Yumi.right.goto_pose(right_pose, linear=True, relative=True, wait_for_res=True)
								break

def onKeyboardEvent(event):
	global teach_done
	global teach_start
	global playback_start
	global playback_done
	global speed_down
	global myo_done
	global myo_start
	#print "Key:", event.Key
	
	if(event.Key == "Escape"):
		if(teach_done == 0):
			print("\n###  Teaching_done:  ###")
			teach_done = 1
			playback_start = 0
			teach_start = 0
			myo_start = 0
			
		if(playback_done == 0):
			print("\n###  Playback_done:  ###")
			playback_done = 1
			teach_start = 0
			playback_start = 0
			myo_start = 0
			
		if(myo_done == 0):
			print("\n###  Myo_done:  ###")
			myo_done = 1
			myo_start = 0
			playback_start = 0
			teach_start = 0	
			
	if(event.Key == "T"):
		if(teach_start == 0):
			print("\n#########  Teach start:  ##########")
			teach_start = 1
			teach_done = 0
			playback_start = -1
			myo_start = -1
	
	if(event.Key == "D"):
		if(teach_start or playback_start == 1) and (speed_down == 0):
			print("\n#########  Speed_Down:  ##########")
			speed_down = 1
			
	if(event.Key == "U"):
		if(teach_start or playback_start == 1) and (speed_down == 1):
			print("\n#########  Speed_up:  ##########")
			speed_down = 0
			
	if(event.Key == "R"):
		if(playback_start == 0):
			print("\n#########  Playback start:  ##########")
			playback_start = 1
			playback_done = 0
			teach_start = -1
			myo_start = -1
	
	if(event.Key == "M"):
		if(myo_start == 0):
			print("\n#########  MYO start:  ##########")
			myo_start = 1
			myo_done = 0
			teach_start = -1
			playback_start = -1
'''
def getkeyboard():
	hm = pyHook.HookManager()
	hm.KeyDown = onKeyboardEvent
	hm.HookKeyboard()
	pythoncom.PumpMessages()
'''
if __name__ == '__main__':
	with_initial = 1
	#t1 = threading.Thread(target=getkeyboard)
	#t1.setDaemon(True)
	#t1.start()
	run = TPM()
	#Yumi = YuMiRobot()
	#state_R=[68.64,-73.40,55.68,-149.01,78.72,78.97,-93.21]
	#trans_pl =[-0.0400449,0.08783,0.1405,0.29074]#[-0.0400449,0.08783,0.189389,0.28552]#改Z轴
	# 这三个点是？
	point_R = [0.17387, -0.31687, 0.088]
	point_1 = [0.24545, -0.15344, 0.088]
	point_2 = [0.31885, -0.03162, 0.088]
	'''
	
	'''

	test_main.move_to_tcp(initial_pose)
	time.sleep(default_sleep_time)
	#平滑处理？
	# right_pose = Yumi.right.get_pose()
	# init_pose = right_pose
	# Yumi.right.goto_pose(right_pose, linear=True, relative=True, wait_for_res=True)
	#Yumi.right.goto_pose_delta((0.0, 0.0, 0.0), rotation = (0, 0, -50))
	'''
	state = Yumi.right.get_state()
	print('state0', state)
	clear_data = re.match(r'\[([0-9\.\-]*),[\s]*([0-9\.\-]*),[\s]*([0-9\.\-]*),[\s]*([0-9\.\-]*),[\s]*([0-9\.\-]*),[\s]*([0-9\.\-]*),[\s]*([0-9\.\-]*)[\s]*\]', str(state))	
	state_R_ = []
	for i in range(7):
		if i == 6:
			joint = float(clear_data.group(i+1)) + 29.67
		elif i == 5:
			joint = float(clear_data.group(i + 1)) + 90
		else:
			joint = float(clear_data.group(i + 1))
		state_R_.append(joint)
	print('clear', state_R_)
	state_R=YuMiState(vals=state_R_)
	Yumi.right.goto_state(state_R)
	state_R_[5] -= 90
	state_R = YuMiState(vals=state_R_)
	Yumi.right.goto_state(state_R)
	'''
	#print(str(state))
	'''
	clear_data = re.match(r'\[([0-9\.\-]*),[\s]*([0-9\.\-]*),[\s]*([0-9\.\-]*),[\s]*([0-9\.\-]*),[\s]*([0-9\.\-]*),[\s]*([0-9\.\-]*),[\s]*([0-9\.\-]*)[\s]*\]', str(state))	
	state_R_ = []
	for i in range(7):
		if i == 5:
			joint = float(clear_data.group(i+1)) + 90
		else:
			joint = float(clear_data.group(i+1))
		state_R_.append(joint)
	state_R=YuMiState(vals=state_R_)
	Yumi.right.goto_state(state_R)
	print('6 joint 旋转')
	'''
	#初始点
	# right_pose.translation[0] = point_R[0]
	# right_pose.translation[1] = point_R[1]
	# right_pose.translation[2] = point_R[2]
	# Yumi.right.goto_pose(right_pose, linear=True, relative=True, wait_for_res=True)
	# time.sleep(1)


	#这里是要？又一个初始位置？
	# if (with_initial):
	# 		#第一个点
	# 		right_pose.translation[0] = point_1[0]
	# 		#right_pose.translation[1] = point_1[1]#gap position 1
	# 		right_pose.translation[1] = point_1[1] + 0.05 #gap position 2
	#
	#
	# 		Yumi.right.goto_pose(right_pose, linear=True, relative=True, wait_for_res=True)
	# 		time.sleep(1)
	# 		Yumi.right.close_gripper()
	# 		time.sleep(1)
	# 		print("cap point")
	# 		####Test###
	# 		Yumi.right.goto_pose_delta((0.0, 0.0, -(0.105)))#向下10.5cm
	# 		time.sleep(1)
	# 		###########
	# 		print('向下10.5cm')
	# 		Yumi.right.open_gripper()
	# 		Yumi.right.set_gripper_force(25, wait_for_res=True)
	# 		time.sleep(1)
	# 		###########
	# 		Yumi.right.goto_pose_delta((0.0, 0.0, 0.01))
	# 		Yumi.right.goto_pose_delta((0.05, 0.0, 0.155))  # (x,self.y,z)#向cm
	# 		time.sleep(20)
	# 		print('向前5cm, 向上15.5cm')
	# 		####Test###
	# 		#Yumi.right.goto_pose_delta((0.0, 0.0, 0.215))#(x,self.y,z)#向上20.5cm
	# 		#print('向上10.5cm')
	# 		#第二个点
	# 		high_pose = Yumi.right.get_pose()
	# 		right_pose.translation[2] = high_pose.translation[2]
	# 		'''
	# 		right_pose.translation[0] = point_2[0]
	# 		right_pose.translation[1] = point_2[1]
	# 		Yumi.right.goto_pose(right_pose, linear=True, relative=True, wait_for_res=True)
	# 		'''
	# 		final_pose = right_pose
	# 		print('rl start point')
	# 		print(final_pose)
	# 		#把当前点作为初始点写入Yumi_point.txt
	# 		with open("Yumi_point.txt","w") as text_file:
	# 			text_file.write("{:.3f}\n{:.3f}\n{:.3f}\n".format(point_2[0], point_2[1], point_2[2]))

	while True:

			# if teach_start == 1:
			# 	run.Teaching(teach_file_name='Right_statenew.txt')
			# if playback_start == 1:
			# 	run.Playback(restore_file_name='Right_statenew.txt', column_data=8)
			if myo_start == 1:
				print('point_R is')
				print(point_R)
				run.Myo_controll(point_R, 0.01)

		#sub.stop()

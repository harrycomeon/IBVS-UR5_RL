import numpy as np

import sys
import pyrealsense2 as rs
import re

sys.path.remove('/opt/ros/kinetic/lib/python2.7/dist-packages')
import cv2
'''
if len(sys.argv) != 2:
    print('Input video name is missing')
    exit()
'''

print('Select 2 tracking targets')

cv2.namedWindow("tracking")
#camera = cv2.VideoCapture(2)
tracker = cv2.MultiTracker_create()
init_once = False

# Configure depth and color streams
pipeline = rs.pipeline()
config = rs.config()
config.enable_stream(rs.stream.depth, 640, 480, rs.format.z16, 30)
config.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)

# Start streaming
pipeline.start(config)

# Wait for a coherent pair of frames: depth and color
frames = pipeline.wait_for_frames()
depth_frame = frames.get_depth_frame()
color_frame = frames.get_color_frame()

# Convert images to numpy arrays
depth_image = np.asanyarray(depth_frame.get_data())
color_image = np.asanyarray(color_frame.get_data())
print(depth_image)
# Apply colormap on depth image (image must be converted to 8-bit per pixel first)
depth_colormap = cv2.applyColorMap(cv2.convertScaleAbs(depth_image, alpha=0.03), cv2.COLORMAP_JET)

# Stack both images horizontally
image = np.hstack((color_image, depth_colormap))

#ok, image=camera.read()
# if not ok:
#     print('Failed to read video')
#     exit()

bbox1 = cv2.selectROI('tracking', image)
bbox2 = cv2.selectROI('tracking', image)
#bbox3 = cv2.selectROI('tracking', image)

while True:
   # ok, image=camera.read()

    # Wait for a coherent pair of frames: depth and color
    frames = pipeline.wait_for_frames()
    depth_frame = frames.get_depth_frame()
    color_frame = frames.get_color_frame()
    if not depth_frame or not color_frame:
        print('no image to read')
        break

    # Convert images to numpy arrays
    depth_image = np.asanyarray(depth_frame.get_data())
    print(np.shape(depth_image))
    color_image = np.asanyarray(color_frame.get_data())
    #print(np.shape(color_image))
    # Apply colormap on depth image (image must be converted to 8-bit per pixel first)
    depth_colormap = cv2.applyColorMap(cv2.convertScaleAbs(depth_image, alpha=0.03), cv2.COLORMAP_JET)
   # print(np.shape(depth_colormap))
    # Stack both images horizontally
    image = np.hstack((color_image, depth_colormap))


    if not init_once:
        ok = tracker.add(cv2.TrackerMIL_create(), image, bbox1)
        ok = tracker.add(cv2.TrackerMIL_create(), image, bbox2)
        #ok = tracker.add(cv2.TrackerMIL_create(), image, bbox3)
        init_once = True

    ok, boxes = tracker.update(image)

   # print(ok, boxes)
    x1,y1,w1,h1 = boxes[0][0], boxes[0][1],boxes[0][2],boxes[0][3]
    x2,y2,w2,h2 = boxes[1][0], boxes[1][1],boxes[1][2],boxes[1][3]
    print (x1,y1,w1,h1)

    d0 = depth_image[int(y1+h1/2), int(x1+w1/2)]
    d1 = depth_image[int(y2+h2/2), int(x2+w2/2)]
    # print(d0)
    # print(d1)
    dd = float(d0) - float(d1)
   # print(dd)
    print(int(y1+h1/2), int(x1+w1/2))
    print(int(y2+h2/2), int(x2+w2/2))
    with open("outd.txt", "w") as text_file:
        thing = boxes[0] - boxes[1]
        #text_file.write(str(thing[0])+' '+str(thing[1])+' '+str(dd))
        text_file.write(str(x1+w1/2-x2-w2/2) + ' ' + str(y1+h1/2-y2-h2/2) + ' ' + str(dd))
    #
    # print(depth_image[boxes[0][1],boxes[0][0]])
    # print(depth_image[boxes[1][1],boxes[1][0]])
    with open(r'/home/cuiben/study_code/UR5_RL/outd.txt', 'r') as f:
        t_picture = f.read()
  #  clear_data = re.match(r'dx:([0-9\.\-]*)[\s]*dy:([0-9\.\-]*)[\s]*ddepth:([0-9\.\-]*)[\s]*', t_picture)
    t_picture = t_picture.strip('\n').split(' ')
    print(float(t_picture[0]))
    for newbox in boxes:
        p1 = (int(newbox[0]), int(newbox[1]))
        p2 = (int(newbox[0] + newbox[2]), int(newbox[1] + newbox[3]))
        cv2.rectangle(image, p1, p2, (200,0,0))

    cv2.imshow('tracking', image)
    k = cv2.waitKey(1)
    if k == 27 : break # esc pressed

## License: Apache 2.0. See LICENSE file in root directory.
## Copyright(c) 2015-2017 Intel Corporation. All Rights Reserved.

###############################################
##      Open CV and Numpy integration        ##
###############################################

# import pyrealsense2 as rs
# import numpy as np
# import cv2
#
# # Configure depth and color streams
# pipeline = rs.pipeline()
# config = rs.config()
# config.enable_stream(rs.stream.depth, 640, 480, rs.format.z16, 30)
# config.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)
#
# # Start streaming
# pipeline.start(config)
#
# try:
#     while True:
#
#         # Wait for a coherent pair of frames: depth and color
#         frames = pipeline.wait_for_frames()
#         depth_frame = frames.get_depth_frame()
#         color_frame = frames.get_color_frame()
#         if not depth_frame or not color_frame:
#             continue
#
#         # Convert images to numpy arrays
#         depth_image = np.asanyarray(depth_frame.get_data())
#         color_image = np.asanyarray(color_frame.get_data())
#
#         # Apply colormap on depth image (image must be converted to 8-bit per pixel first)
#         depth_colormap = cv2.applyColorMap(cv2.convertScaleAbs(depth_image, alpha=0.03), cv2.COLORMAP_JET)
#
#         # Stack both images horizontally
#         images = np.hstack((color_image, depth_colormap))
#
#         # Show images
#         cv2.namedWindow('RealSense', cv2.WINDOW_AUTOSIZE)
#         cv2.imshow('RealSense', images)
#         cv2.waitKey(1)
#
# finally:
#
#     # Stop streaming
#     pipeline.stop()

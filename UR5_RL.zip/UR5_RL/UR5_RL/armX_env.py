#!/usr/bin/python
# -*-coding: UTF-8 -*-
"""
Environment for Robot Arm.
You can customize this script in a way you want.

View more on [莫烦Python] : https://morvanzhou.github.io/tutorials/


Requirement:
pyglet >= 1.2.4
numpy >= 1.12.1
"""
import numpy as np
import re
import time

class ArmEnv(object):
#	action_bound = [-0.0001, 0.001]#[-0.15, 0.15]
#	action_bound = [-0.001, 0.01]  #zxq params
#	limit = [[0.33, 0.49], [-0.24, -0.06]]#[[0.255, 0.445], [-0.255, 0.255]]
	action_bound = [-0.01, 0.01]
	limit = [[-0.59, 0.49], [-0.24, -0.06]]
	action_dim = 1
	state_dim = 2
	dt = 1  # refresh rate
	viewer = None
	get_point = False
	point_l = 6
	grab_counter = 0
	dx=0
	dy=0
	dz=0
	l=[0,0,0,0]

	def __init__(self, LOAD, online_graph, mode='easy'):
		# node1 (l, d_rad, x, y),
		# node2 (l, d_rad, x, y)
		self.mode = mode
		#初始化Yumi手臂位置
		self.point_R = [0.34554, -0.15408, 0.20862]#[0.17387,-0.31687,0.077]#换成初始坐标
		self.LOAD = LOAD
		self.online_graph = online_graph
		
	def step(self,action):
		#实时读取outd，获取action(Yumi位置变化)下的state
		# action = (node1 angular v, node2 angular v)
		#action = np.clip(action, *self.action_bound)
		#self.arm_info[:, 1] += action * self.dt
		# print("step:before action*self.dt")
		# print(self.point_R)
		# print(action)
		# print(self.dt)
		# print()
		self.point_R[0] += action[0] * self.dt
		# print("step:after action*self.dt")
		# print(self.point_R)
		if self.point_R[0] > self.limit[0][1]:
			#self.point_R[0] = self.point_R[0] - limit[0][1] + limit[0][0]
			self.l[1]=self.l[1]+1
		elif self.point_R[0] < self.limit[0][0]:
			self.l[0]=self.l[0]+1			

		#test#
		
		if self.point_R[0] > self.limit[0][1]:
			self.point_R[0] = self.point_R[0] - self.limit[0][1] + self.limit[0][0]
		elif self.point_R[0] < self.limit[0][0]:
			self.point_R[0] = self.point_R[0] - self.limit[0][0] + self.limit[0][1]
		
		######

		self.point_R[0] = np.clip(self.point_R[0], *self.limit[0])

		s, ddistance = self._get_state()
		#print (ddistance)
		r = self._r_func(ddistance)
		#print ('r:', r)
		return s, r, self.get_point

	def reset(self):
		self.get_point = False
		self.grab_counter = 0
		self.l = [0,0,0,0] 
		if self.mode == 'hard':
		#任意框位置模式hard
		#等待按键开始后面程序，这个时间随机移动框位置，以便继续下一回合学习
			#pxy = np.clip(np.random.rand(2) * self.viewer_xy[0], 100, 300)
			#self.point_info[:] = pxy
			pass
			
		else:
		#固定框位置模式easy
		#随机改变Yumi末端位置，以便继续下一回合学习
			'''
			move_xy = -0.02+np.random.rand(2) * 0.02 * 2#-0.1m~0.1m
			self.point_R[:2] += move_xy 
			self.point_R[0] = np.clip(self.point_R[0], *self.limit[0])
			self.point_R[1] = np.clip(self.point_R[1], *self.limit[1])
			'''
			if not self.LOAD:
				self.point_R[0] = np.random.uniform(0.27, 0.42, 1)[0]
			#self.point_R[0] = 0.27
			print ('reset: ',self.point_R[0])

		return self._get_state()[0]

	def render(self):
		#将action信息写入控制Yumi文件,更新机械手位置
		self.mover = Move(self.point_R)
		self.mover.render()

	def sample_action(self):

		return np.random.uniform(*self.action_bound, size=self.action_dim)

	def _get_state(self):
		# return the distance (dx, dy) between arm finger point with blue point
		#读文件：
		#while (True):
		#with open(r'F:\XJY_c++\Multi_kcf\Multi_kcf\outd.txt', 'r') as f:
		#with open(r'C:\Users\lenovo\Desktop\程序\KCF跟踪\multi_3dmouse\multi_3dmouse\outd.txt', 'r') as f:
		# with open(r'/home/zxq/projects/my_kcf/build/outd.txt', 'r') as f:
		with open(r'/home/cuiben/study_code/UR5_RL/outd.txt', 'r') as f:
			t_picture = f.read()
		#print (t_picture)
		# clear_data = re.match(r'dx:([0-9\.\-]*)[\s]*dy:([0-9\.\-]*)[\s]*ddepth:([0-9\.\-]*)[\s]*', t_picture)
		# if clear_data !=None:
		# 	self.dx = float(clear_data.group(1))#dx
		# 	self.dz = float(clear_data.group(2))#dy
		# 	self.dy = float(clear_data.group(3))#ddepth
		t_picture = t_picture.strip('\n').split(' ')
		if t_picture[0] != '':
			if t_picture !=None:
				self.dx = float(t_picture[0])#dx
				self.dz = float(t_picture[1])#dy
				self.dy = float(t_picture[2])#ddepth

		in_point = 1 if self.grab_counter > 0 else 0
		ddistance = [self.dx]
		# if self.online_graph:
		# 	with open("X_dist.txt","a") as x_dist:
		# 		x_dist.write("{:.3f}\n".format(self.dx))
		#print (ddistance)
		#absList = list(map(abs, ddistance))
		#if (absList < [175,175]):
		#	break
		#print (self.dx)
		return np.hstack([in_point, self.dx/100]), ddistance

	def _r_func(self, distance):
		t = 50#50
		#print (distance,)
		abs_distance = abs(distance[0])
		#print(abs_distance)
		r = -abs_distance/100
		#print ('reward: ',r)
		if abs_distance < self.point_l and (not self.get_point):
			r += 1.
			self.grab_counter += 1
			if self.grab_counter > t:
				r += 10.
				self.get_point = True
		elif abs_distance > self.point_l:
			self.grab_counter = 0
			self.get_point = False
		# with open("reward.txt","a") as x_dist:
		# 	x_dist.write("{:.3f}\n".format(r))
		return r


class Move(object):

	def __init__(self, point_R):
		self.point_R = point_R
		self.pre_point = [0.0,0.0]
		
	def render(self):
		self._update_arm()

	def _update_arm(self):
		#将action信息写入控制Yumi文件
		point = self.point_R
		# print("nexy point is ")
		# print (point)
		#if point[0] - self.pre_point[0]>0.001 and point[1] - self.pre_point[1]>0.001:
		with open("YumiX_point.txt","w") as text_file:
			text_file.write("{:.3f}\n{:.3f}\n{:.3f}\n".format(point[0], point[1], point[2]))     
		self.pre_point[0] = point[0]
		#self.pre_point[1] = point[1]
if __name__ == '__main__':
	env = ArmEnv()
	while True:
		env.render()
		env.step(env.sample_action())
		#time.sleep(2)
